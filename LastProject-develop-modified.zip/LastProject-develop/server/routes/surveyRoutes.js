const mongoose=require('mongoose');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:60000/";
const MONGO_URL = 'mongodb://sunil:sunil@ds163689.mlab.com:63689/mydb1';

const requireLogin = require('../middlewares/requireLogin')
const requireCredits=require('../middlewares/requireCredits')
const Mailer =require('../services/Mailer');
const surveyTemplate=require('../services/emailTemplates/surveyTemplate')
const _ =require('lodash');
const Path=require('path-parser');
const {URL}=require('url')


//var MongoClient = require('mongodb').MongoClient
  //var assert = require('assert');
//var url = 'mongodb://localhost:60000/myproject'

/*var con = mysql.createConnection({
  host: "localhost",
  user: "myusername",
  password: "mypassword",
  database: "mydb"
});*/


const Survey=mongoose.model('surveys');
console.log(Path);

module.exports=app=>{
	app.get('/api/surveys',requireLogin,async (req,res)=>{
		const surveys=await Survey.find({_user:req.user.id}).select({
			recipients:false
		});
		res.send(surveys);
	})
	app.get('/api/surveys/:surveyId/:choice',(req,res)=>{
		res.send("Thanks for the feedback");
	})

	app.get('/api/surveys1',(req,res)=>{
		var  brand = req.query.Brand;
		var rating =req.query.rating;
		var review=req.query.review;
		res.send(brand+" "+ rating +" "+review);
		/*MongoClient.connect(MONGO_URL, (err, db) => {  
		  if (err) {
		    return console.log(err);
		  }

		  // Do something with db here, like inserting a record
		  db.collection('customers').insertOne(
		    {
			    BrandName : brand,
			    Rating :rating,
			Review : review
		
		    },
		    function (err, res) {
		      if (err) {
			db.close();
			return console.log(err);
		      }
		      // Success
		      db.close();
		    }
		  )
		});*/
		

		
		MongoClient.connect(url, function(err, db) {
 	        if (err) throw err;
 		var dbo = db.db("mydb1");
  		var myobj = { BrandName:brand ,Rating: rating, Review: review  };
  		dbo.collection("customers").insertOne(myobj, function(err, res) {
   		if (err) throw err;
   		console.log("1 document inserted");
		

    		db.close();
  		});});
		
		/*MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb1");
  dbo.collection("customers").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});
*/
		
	})

	app.post('/api/surveys/webhooks',(req,res)=>{
		const events=_.map(req.body,({email,url})=>{
			const pathname = new URL(url).pathname;
			const p=new Path('/api/surveys/:surveyId/:choice');
			const match=p.test(pathname);
			if(match){
				return {email,surveyId:match.surveyId,choice:match.choice};
			}	
		})
		const compactEvents = _.compact(events);
		const uniqueEvents = _.uniqBy(compactEvents,'email','surveyId');
		console.log(uniqueEvents);
		uniqueEvents.forEach(event=>{
			Survey.updateOne({
    			_id: event.surveyId,
    			recipients: {
        			$elemMatch: { email: event.email, responded: false }
    			}

			}, {

    			$inc: {[event.choice]: 1 },
    			$set: { 'recipients.$.responded': true }

			}).exec();
		})
		res.send({});
	})
	app.post('/api/surveys',requireLogin,requireCredits,async (req,res)=>{
		const {title,subject,body,recipients}=req.body;
		const survey=new Survey({
			title,
			subject,
			body,
			recipients:recipients.split(',').map(email=>({email:email.trim()})),
			_user:req.user.id,
			dateSent:Date.now()
		})

		const mailer=new Mailer(survey,surveyTemplate(survey));
		try{
			await mailer.send();
			await survey.save();
			req.user.credits-=1;
			const user= await req.user.save();
			res.send(user);
		}catch(err){
			res.status(422).send(err);
		}
	})
}
