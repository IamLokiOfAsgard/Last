module.exports=(survey)=>{
	return `
	<html>
		<body>
			<div style="text-align:center;">
				<h3>I'd Like Your Input!</h3>
				<p>Please answer the following question:</p>
				<p>${survey.body}</p>
				<div>
					<a href="http://localhost:3000/api/surveys/${survey.id}/yes">Yes</a>
				</div>
				<div>
					<a href="http://localhost:3000/api/surveys/${survey.id}/no">No</a>
				</div>
				<form action="http://localhost:3000/api/surveys1" method="get">
				
				<div>
				
				Brand : 
				
				</div>
				<div>
				
				<select name="Brand">
				    <option value="Apple">Apple</option>
				    <option value="Micromax">Micromax</option>
				    <option value="Intex">Intex</option>
				    <option value="Vivo">Vivo</option>
				    <option value="Oppo">Oppo</option>
				    <option value="Mi">Mi</option>
				    <option value="Htc">Htc</option>
				    <option value="Nokia">Nokia</option>
				    <option value="Blackberry">Blackberry</option>
				    <option value="Sony">Sony</option>
				    <option value="BLU">BLU</option>
				    <option value="LG">LG</option>
				    <option value="MOtorola">Motorola</option>
				    <option value="CNPGD">CNPGD</option>
				    <option value="Lenovo">Lenovo</option>
				    <option value="Oneplus">OnePlus</option>
				</select> 
				
				</div>				

				<div>
				
				Rating : 
				
				</div>
				<div>
					<input type="number" name="rating" min="1" max="5"/>
				</div>
				<div>
				
				Review : 
				
				</div>
				<div>
					<input type="text" name="review" />
				</div>
				<div>
					<input type="submit" />
				</div>
				</form>
			</div>
		</body>
	</html>



	`;
}
