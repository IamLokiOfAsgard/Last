export const FETCH_USER='fetch';
export const FETCH_SURVEYS='fetch_surveys';